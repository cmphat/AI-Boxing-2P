import cv2
import numpy as np
import pygame


WIDTH = 1100
HEIGHT = 700
FPS = 60

BG = (18, 24, 38)
WHITE = (245, 247, 250)
MUTED = (165, 175, 192)
BLUE = (56, 155, 255)
RED = (255, 91, 91)
GREEN = (69, 205, 139)
YELLOW = (255, 208, 92)
DARK = (31, 40, 58)


class BoxingGame:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("AI BOXING - 2 PLAYERS")
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()

        self.font_small = pygame.font.SysFont("arial", 18)
        self.font = pygame.font.SysFont("arial", 24, bold=True)
        self.font_big = pygame.font.SysFont("arial", 42, bold=True)
        self.font_title = pygame.font.SysFont("arial", 52, bold=True)

        self.reset()

    def reset(self):
        self.players = [
            {
                "name": "PLAYER 1",
                "color": BLUE,
                "health": 100,
                "attack_timer": 0.0,
                "hit_flash": 0.0,
                "cooldown": 0.0,
                "guard": False,
                "message": "",
                "message_timer": 0.0,
            },
            {
                "name": "PLAYER 2",
                "color": RED,
                "health": 100,
                "attack_timer": 0.0,
                "hit_flash": 0.0,
                "cooldown": 0.0,
                "guard": False,
                "message": "",
                "message_timer": 0.0,
            },
        ]
        self.round_seconds = 90.0
        self.game_over = False
        self.winner_text = ""

    def keyboard_punch(self, player_index):
        if not self.game_over:
            self._apply_punch(player_index)

    def _apply_punch(self, attacker_index):
        attacker = self.players[attacker_index]
        defender_index = 1 - attacker_index
        defender = self.players[defender_index]

        if attacker["cooldown"] > 0:
            return

        attacker["attack_timer"] = 0.26
        attacker["cooldown"] = 0.48

        if defender["guard"]:
            damage = 2
            defender["message"] = "BLOCK!"
        else:
            damage = 10
            defender["message"] = f"-{damage} HP"

        defender["health"] = max(0, defender["health"] - damage)
        defender["hit_flash"] = 0.22
        defender["message_timer"] = 0.55

    def update(self, dt, gestures):
        if not self.game_over:
            self.round_seconds = max(0.0, self.round_seconds - dt)

        for i, player in enumerate(self.players):
            player["attack_timer"] = max(0.0, player["attack_timer"] - dt)
            player["hit_flash"] = max(0.0, player["hit_flash"] - dt)
            player["cooldown"] = max(0.0, player["cooldown"] - dt)
            player["message_timer"] = max(0.0, player["message_timer"] - dt)
            player["guard"] = bool(gestures[i].get("guard", False))

        if not self.game_over:
            for i in range(2):
                if gestures[i].get("punch", False):
                    self._apply_punch(i)

            if self.players[0]["health"] <= 0:
                self.game_over = True
                self.winner_text = "PLAYER 2 WINS!"
            elif self.players[1]["health"] <= 0:
                self.game_over = True
                self.winner_text = "PLAYER 1 WINS!"
            elif self.round_seconds <= 0:
                h1 = self.players[0]["health"]
                h2 = self.players[1]["health"]
                if h1 > h2:
                    self.winner_text = "PLAYER 1 WINS!"
                elif h2 > h1:
                    self.winner_text = "PLAYER 2 WINS!"
                else:
                    self.winner_text = "DRAW!"
                self.game_over = True

    def _text(self, text, x, y, font=None, color=WHITE, center=False):
        font = font or self.font
        surface = font.render(str(text), True, color)
        rect = surface.get_rect()
        if center:
            rect.center = (x, y)
        else:
            rect.topleft = (x, y)
        self.screen.blit(surface, rect)

    def _draw_health_bar(self, x, y, player, width=390):
        pygame.draw.rect(self.screen, (55, 64, 82), (x, y, width, 24), border_radius=8)
        fill_width = int(width * player["health"] / 100)
        if fill_width > 0:
            pygame.draw.rect(
                self.screen, player["color"],
                (x, y, fill_width, 24), border_radius=8
            )
        pygame.draw.rect(self.screen, WHITE, (x, y, width, 24), 2, border_radius=8)
        self._text(f'{player["health"]:3d} HP', x + width - 75, y + 30,
                   self.font_small, WHITE)

    def _draw_ring(self):
        # Nen va san dau
        pygame.draw.rect(self.screen, (42, 52, 73), (75, 300, 950, 315), border_radius=22)
        pygame.draw.rect(self.screen, (225, 230, 240), (95, 320, 910, 275), 5)
        for y, color in [(375, (220, 70, 80)), (430, (230, 230, 240)), (485, (65, 140, 235))]:
            pygame.draw.line(self.screen, color, (95, y), (1005, y), 7)
        pygame.draw.rect(self.screen, (30, 37, 53), (95, 510, 910, 85))
        pygame.draw.line(self.screen, (90, 105, 130), (550, 320), (550, 595), 2)
        for x, y in [(95, 320), (1005, 320), (95, 595), (1005, 595)]:
            pygame.draw.circle(self.screen, WHITE, (x, y), 9)

    def _draw_fighter(self, x, base_y, player, facing, player_index):
        color = player["color"]
        dark = tuple(max(0, c - 65) for c in color)
        flash = player["hit_flash"] > 0
        if flash:
            color = YELLOW

        # Dau va than
        head_center = (x, base_y - 174)
        pygame.draw.circle(self.screen, (232, 190, 153), head_center, 31)
        pygame.draw.arc(
            self.screen, (45, 35, 35),
            (x - 31, base_y - 205, 62, 48), 0.1, 3.0, 7
        )
        torso = [
            (x - 39, base_y - 143), (x + 39, base_y - 143),
            (x + 48, base_y - 65), (x - 48, base_y - 65)
        ]
        pygame.draw.polygon(self.screen, dark, torso)
        pygame.draw.polygon(self.screen, color, [
            (x - 30, base_y - 137), (x + 30, base_y - 137),
            (x + 34, base_y - 75), (x - 34, base_y - 75)
        ])

        # Quan boxing
        pygame.draw.line(self.screen, (35, 40, 55), (x - 32, base_y - 70),
                         (x - 48, base_y - 12), 17)
        pygame.draw.line(self.screen, (35, 40, 55), (x + 32, base_y - 70),
                         (x + 48, base_y - 12), 17)
        pygame.draw.line(self.screen, WHITE, (x - 48, base_y - 12),
                         (x - 58, base_y - 4), 9)
        pygame.draw.line(self.screen, WHITE, (x + 48, base_y - 12),
                         (x + 58, base_y - 4), 9)

        # Tay truoc va tay sau
        direction = facing
        shoulder_front = (x + direction * 29, base_y - 130)
        shoulder_back = (x - direction * 29, base_y - 130)

        if player["attack_timer"] > 0:
            elbow_front = (x + direction * 80, base_y - 122)
            glove_front = (x + direction * 142, base_y - 119)
        else:
            elbow_front = (x + direction * 57, base_y - 105)
            glove_front = (x + direction * 38, base_y - 91)

        elbow_back = (x - direction * 52, base_y - 104)
        glove_back = (x - direction * 30, base_y - 91)

        for shoulder, elbow, glove in [
            (shoulder_front, elbow_front, glove_front),
            (shoulder_back, elbow_back, glove_back),
        ]:
            pygame.draw.line(self.screen, (232, 190, 153), shoulder, elbow, 17)
            pygame.draw.line(self.screen, (232, 190, 153), elbow, glove, 15)
            pygame.draw.circle(self.screen, color, glove, 18)
            pygame.draw.circle(self.screen, WHITE, glove, 18, 2)

        # Dai that lung va logo
        pygame.draw.rect(self.screen, WHITE, (x - 42, base_y - 72, 84, 13), border_radius=4)
        pygame.draw.circle(self.screen, color, (x, base_y - 106), 7)

        if player["guard"]:
            self._text("GUARD", x, base_y - 238, self.font_small, GREEN, center=True)
        elif player["attack_timer"] > 0:
            self._text("PUNCH!", x, base_y - 238, self.font_small, YELLOW, center=True)

        if player["message_timer"] > 0:
            self._text(player["message"], x, base_y - 270, self.font, YELLOW, center=True)

        self._text(player["name"], x, base_y + 8, self.font_small, WHITE, center=True)

    def _draw_camera(self, camera_frame, people):
        x, y, w, h = WIDTH - 285, 95, 260, 195
        pygame.draw.rect(self.screen, (8, 12, 20), (x - 4, y - 4, w + 8, h + 8), border_radius=8)
        pygame.draw.rect(self.screen, WHITE, (x - 4, y - 4, w + 8, h + 8), 2, border_radius=8)

        if camera_frame is not None:
            small = cv2.resize(camera_frame, (w, h))
            rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
            surface = pygame.surfarray.make_surface(np.transpose(rgb, (1, 0, 2)))
            self.screen.blit(surface, (x, y))
        else:
            pygame.draw.rect(self.screen, DARK, (x, y, w, h))
            self._text("NO CAMERA", x + w // 2, y + h // 2,
                       self.font_small, WHITE, center=True)

        count = sum(1 for p in people if p is not None)
        status = f"POSE TRACKING: {count}/2"
        self._text(status, x, y + h + 8, self.font_small,
                   GREEN if count == 2 else YELLOW)

    def draw(self, camera_frame, people):
        self.screen.fill(BG)

        # Header
        self._text("AI BOXING", WIDTH // 2, 34, self.font_title, WHITE, center=True)
        self._text("2 PLAYERS  |  CAMERA POSE CONTROL", WIDTH // 2, 78,
                   self.font_small, MUTED, center=True)

        self._text("PLAYER 1", 75, 112, self.font, BLUE)
        self._draw_health_bar(75, 145, self.players[0], 390)
        self._text("PLAYER 2", 600, 112, self.font, RED)
        self._draw_health_bar(600, 145, self.players[1], 390)

        timer_text = f"{int(self.round_seconds // 60):02d}:{int(self.round_seconds % 60):02d}"
        self._text(timer_text, WIDTH // 2, 165, self.font_big, YELLOW, center=True)

        self._draw_ring()
        self._draw_fighter(340, 575, self.players[0], facing=1, player_index=0)
        self._draw_fighter(760, 575, self.players[1], facing=-1, player_index=1)

        self._draw_camera(camera_frame, people)

        self._text(
            "P1: stand LEFT  |  P2: stand RIGHT  |  A / L: test punch  |  R: restart  |  ESC: quit",
            WIDTH // 2, 665, self.font_small, MUTED, center=True
        )

        if self.game_over:
            overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 165))
            self.screen.blit(overlay, (0, 0))
            self._text(self.winner_text, WIDTH // 2, HEIGHT // 2 - 25,
                       self.font_title, YELLOW, center=True)
            self._text("Press R to play again  |  ESC to exit",
                       WIDTH // 2, HEIGHT // 2 + 35,
                       self.font, WHITE, center=True)

        pygame.display.flip()

    def close(self):
        pygame.quit()
