from pathlib import Path
import math
import time

import mediapipe as mp
from mediapipe.tasks.python import vision


MODEL_PATH = Path(__file__).resolve().parent / "assets" / "pose_landmarker_lite.task"

# Landmark indices theo MediaPipe Pose:
# vai: 11,12 | khuyu tay: 13,14 | co tay: 15,16
# mui: 0 | hong: 23,24
UPPER_BODY_CONNECTIONS = [
    (11, 12), (11, 13), (13, 15), (12, 14), (14, 16),
    (11, 23), (12, 24), (23, 24),
    (11, 0), (12, 0),
]
LOWER_BODY_CONNECTIONS = [
    (23, 25), (25, 27), (24, 26), (26, 28),
]


def _distance3(a, b):
    return math.sqrt(
        (a[0] - b[0]) ** 2 +
        (a[1] - b[1]) ** 2 +
        (a[2] - b[2]) ** 2
    )


def _angle_at_joint(a, b, c):
    """Goc A-B-C tai khuyu tay, don vi degree."""
    ba = (a[0] - b[0], a[1] - b[1], a[2] - b[2])
    bc = (c[0] - b[0], c[1] - b[1], c[2] - b[2])
    dot = sum(ba[i] * bc[i] for i in range(3))
    norm_ba = math.sqrt(sum(v * v for v in ba))
    norm_bc = math.sqrt(sum(v * v for v in bc))
    if norm_ba < 1e-8 or norm_bc < 1e-8:
        return 0.0
    cosine = max(-1.0, min(1.0, dot / (norm_ba * norm_bc)))
    return math.degrees(math.acos(cosine))


class PoseTracker:
    """
    Nhan dien toi da 2 nguoi trong cung mot khung hinh.
    Nguoi o nua trai khung hinh -> Player 1.
    Nguoi o nua phai khung hinh -> Player 2.

    Punch heuristic:
    - Khuu tay duoc duoi gan thang.
    - Co tay dang di chuyen nhanh.
    - Moi tay co cooldown/re-arm de khong tinh lap lien tuc.
    """

    def __init__(self):
        if not MODEL_PATH.exists():
            raise FileNotFoundError(
                f"Khong tim thay model: {MODEL_PATH}\n"
                "Hay chay: python download_model.py"
            )

        base_options = mp.tasks.BaseOptions(
            model_asset_path=str(MODEL_PATH)
        )
        options = vision.PoseLandmarkerOptions(
            base_options=base_options,
            running_mode=vision.RunningMode.VIDEO,
            num_poses=2,
            min_pose_detection_confidence=0.50,
            min_pose_presence_confidence=0.50,
            min_tracking_confidence=0.50,
            output_segmentation_masks=False,
        )
        self.landmarker = vision.PoseLandmarker.create_from_options(options)

        self.prev_timestamp_ms = -1
        self.prev_wrist = [[None, None], [None, None]]
        self.armed = [[True, True], [True, True]]
        self.last_punch_time = [0.0, 0.0]

    def close(self):
        if self.landmarker is not None:
            self.landmarker.close()
            self.landmarker = None

    def process(self, rgb_frame, timestamp_ms):
        """
        Input: frame RGB (numpy array).
        Output:
          people: [player1_pose, player2_pose], phan tu co the la None.
          gestures: [{"punch": bool, "guard": bool}, ...]
        """
        if timestamp_ms <= self.prev_timestamp_ms:
            timestamp_ms = self.prev_timestamp_ms + 1

        mp_image = mp.Image(
            image_format=mp.ImageFormat.SRGB,
            data=rgb_frame
        )
        result = self.landmarker.detect_for_video(mp_image, timestamp_ms)

        dt = 1.0 / 30.0
        if self.prev_timestamp_ms >= 0:
            dt = max(0.005, min(0.15, (timestamp_ms - self.prev_timestamp_ms) / 1000.0))
        self.prev_timestamp_ms = timestamp_ms

        detected = []
        for pose in (result.pose_landmarks or []):
            landmarks = []
            for lm in pose:
                landmarks.append({
                    "x": float(lm.x),
                    "y": float(lm.y),
                    "z": float(lm.z),
                    "visibility": float(getattr(lm, "visibility", 1.0) or 0.0),
                })

            # Dung trung binh hai vai de xac dinh vi tri ngang cua nguoi.
            cx = (landmarks[11]["x"] + landmarks[12]["x"]) / 2.0
            detected.append({
                "landmarks": landmarks,
                "center_x": cx,
            })

        # Sap xep trai -> phai de gan Player 1 va Player 2.
        detected.sort(key=lambda item: item["center_x"])
        people = [None, None]

        if len(detected) >= 2:
            people[0] = detected[0]
            people[1] = detected[1]
        elif len(detected) == 1:
            slot = 0 if detected[0]["center_x"] < 0.5 else 1
            people[slot] = detected[0]

        gestures = [
            {"punch": False, "guard": False, "tracked": False},
            {"punch": False, "guard": False, "tracked": False},
        ]

        now = time.perf_counter()
        for player_index, person in enumerate(people):
            if person is None:
                continue

            lm = person["landmarks"]
            gestures[player_index]["tracked"] = True

            # Guard: ca hai co tay duoc dua len cao gan ngang vai/cam.
            left_wrist = lm[15]
            right_wrist = lm[16]
            shoulder_y = (lm[11]["y"] + lm[12]["y"]) / 2.0
            wrists_visible = (
                left_wrist["visibility"] > 0.35 and
                right_wrist["visibility"] > 0.35
            )
            gestures[player_index]["guard"] = bool(
                wrists_visible and
                left_wrist["y"] < shoulder_y + 0.02 and
                right_wrist["y"] < shoulder_y + 0.02
            )

            # Hai tay: (vai, khuyu, co tay)
            arms = [(11, 13, 15), (12, 14, 16)]
            punch_this_frame = False

            for arm_index, (shoulder_i, elbow_i, wrist_i) in enumerate(arms):
                shoulder = lm[shoulder_i]
                elbow = lm[elbow_i]
                wrist = lm[wrist_i]

                if min(
                    shoulder["visibility"],
                    elbow["visibility"],
                    wrist["visibility"]
                ) < 0.35:
                    continue

                a = (shoulder["x"], shoulder["y"], shoulder["z"])
                b = (elbow["x"], elbow["y"], elbow["z"])
                c = (wrist["x"], wrist["y"], wrist["z"])

                elbow_angle = _angle_at_joint(a, b, c)

                previous = self.prev_wrist[player_index][arm_index]
                speed = 0.0
                if previous is not None:
                    speed = _distance3(c, previous) / dt

                # Re-arm khi nguoi choi gap khuyu tay lai.
                if elbow_angle < 125.0:
                    self.armed[player_index][arm_index] = True

                # Nguong ban dau de demo; co the tinh chinh theo webcam/khoang cach.
                if (
                    self.armed[player_index][arm_index]
                    and elbow_angle > 148.0
                    and speed > 0.45
                    and (now - self.last_punch_time[player_index]) > 0.42
                ):
                    punch_this_frame = True
                    self.armed[player_index][arm_index] = False
                    self.last_punch_time[player_index] = now

                self.prev_wrist[player_index][arm_index] = c

            gestures[player_index]["punch"] = punch_this_frame

        return people, gestures
